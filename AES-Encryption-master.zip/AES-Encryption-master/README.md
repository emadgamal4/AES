# AES-Encryption
# using assembly 8086 to encrypt 128 bit data using 128bit key with AES standards
